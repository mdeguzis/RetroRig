//
//  AudioEngine.h
//  PPSSPP
//
//  Created by rock88 on 15/03/2013.
//  Copyright (c) 2013 Homebrew. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AudioEngine : NSObject

@end
