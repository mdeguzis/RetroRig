Made by tpunix
Only decrypt MH3P
Don't work with scePauth_F7AA47F6