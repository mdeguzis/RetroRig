# Run GDB
echo $NDK
$NDK/ndk-gdb
