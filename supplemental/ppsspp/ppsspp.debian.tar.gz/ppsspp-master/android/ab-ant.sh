ant debug
adb install -r bin/PPSSPP-debug.apk
adb shell am start -n org.ppsspp.ppsspp/org.ppsspp.ppsspp.PpssppActivity