#pragma once

// Just a test of the ARM emitter, playing around with running some code without having the whole emu around.

void ArmEmitterTest();