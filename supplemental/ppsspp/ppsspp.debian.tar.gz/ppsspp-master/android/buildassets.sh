mkdir -p assets
cp ../assets/unknown.png assets
cp ../assets/ui_atlas.zim assets
cp ../assets/ppge_atlas.zim assets
cp -r ../flash0 assets
cp -r ../lang assets
