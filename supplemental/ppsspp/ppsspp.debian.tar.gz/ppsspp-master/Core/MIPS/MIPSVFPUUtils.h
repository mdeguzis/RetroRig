// Copyright (c) 2012- PPSSPP Project.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, version 2.0 or later versions.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License 2.0 for more details.

// A copy of the GPL 2.0 should have been included with the program.
// If not, see http://www.gnu.org/licenses/

// Official git repository and contact information can be found at
// https://github.com/hrydgard/ppsspp and http://www.ppsspp.org/.

#pragma once

#include <cmath>

#include "Core/MIPS/MIPS.h"

#define _VD (op & 0x7F)
#define _VS ((op>>8) & 0x7F)
#define _VT ((op>>16) & 0x7F)

inline int Xpose(int v) {
	return v^0x20;
}

#ifndef M_PI_2
#define M_PI_2     1.57079632679489661923
#endif

inline float vfpu_sin(float angle) {
	angle -= floorf(angle * 0.25f) * 4.f;
	angle *= (float)M_PI_2;
	return sinf(angle);
}

inline float vfpu_cos(float angle) {
	angle -= floorf(angle * 0.25f) * 4.f;
	angle *= (float)M_PI_2;
	return cosf(angle);
}

inline void vfpu_sincos(float angle, float &sine, float &cosine) {
	angle -= floorf(angle * 0.25f) * 4.f;
	angle *= (float)M_PI_2;
#if defined(__linux__) && !defined(ANDROID)  // TODO: Remove this check when we upgrade NDK on the buildbot
	sincosf(angle, &sine, &cosine);
#else
	sine = sinf(angle);
	cosine = cosf(angle);
#endif
}

#define VFPU_FLOAT16_EXP_MAX    0x1f
#define VFPU_SH_FLOAT16_SIGN    15
#define VFPU_MASK_FLOAT16_SIGN  0x1
#define VFPU_SH_FLOAT16_EXP     10
#define VFPU_MASK_FLOAT16_EXP   0x1f
#define VFPU_SH_FLOAT16_FRAC    0
#define VFPU_MASK_FLOAT16_FRAC  0x3ff

enum VectorSize
{
	V_Single,
	V_Pair,
	V_Triple,
	V_Quad,
};

enum MatrixSize
{
	M_2x2,
	M_3x3,
	M_4x4,
};

void ReadMatrix(float *rd, MatrixSize size, int reg);
void WriteMatrix(const float *rs, MatrixSize size, int reg);

void WriteVector(const float *rs, VectorSize N, int reg);
void ReadVector(float *rd, VectorSize N, int reg);

void GetVectorRegs(u8 regs[4], VectorSize N, int vectorReg);
void GetMatrixRegs(u8 regs[16], MatrixSize N, int matrixReg);

// Returns a number from 0-7, good for checking overlap for 4x4 matrices.
inline int GetMtx(int matrixReg) {
	return (matrixReg >> 2) & 7;
}

VectorSize GetVecSize(MIPSOpcode op);
MatrixSize GetMtxSize(MIPSOpcode op);
VectorSize GetHalfVectorSize(VectorSize sz);
VectorSize GetDoubleVectorSize(VectorSize sz);
int GetNumVectorElements(VectorSize sz);
int GetMatrixSide(MatrixSize sz);
const char *GetVectorNotation(int reg, VectorSize size);
const char *GetMatrixNotation(int reg, MatrixSize size);

float Float16ToFloat32(unsigned short l);
